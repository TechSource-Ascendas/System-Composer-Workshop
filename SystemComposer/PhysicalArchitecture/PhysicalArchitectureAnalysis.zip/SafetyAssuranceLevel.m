classdef SafetyAssuranceLevel < Simulink.IntEnumType
    % SafetyAssuranceLevel Enumeration type definition for use with System Composer profile

    enumeration
        Unset(0)
        A(1)
        B(2)
        C(3)
    end

end
