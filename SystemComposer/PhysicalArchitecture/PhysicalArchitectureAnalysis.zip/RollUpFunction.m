function RollUpFunction(instance,varargin)
    % RollUpFunction: Analysis Function to roll up the stereotype property
    % values of the PhysicalProperties stereotype:
    % Cost, Mass, and PowerConsumption
    
    % This line will display "iter" in the command window each time this
    % function is called, for debugging purposes.
    % disp("iter");
    
    % Only execute the following code if the instance is a component
    % (ignore ports, connectors, and interfaces).
	if instance.isComponent() 
        
        % Check to see if this component has the "PhysicalProperties"
        % stereotype assigned to it. Otherwise, do nothing.
        componentType = instance.Specification.getStereotypes;
        
        if componentType == "PhysicalProfile.PhysicalProperties"
            % This line will display the name of the current component
            % being iterated on, for debug purposes.
            % disp("Component: " + instance.Name); 
            
            % If this component has children then the script will iterate
            % through the children and add their values to the parent
            % component.
            if ~isempty(instance.Components)
                % Create placeholders to sum up the values from the child
                % parts.
                Parent.Cost = 0;
                Parent.Mass = 0;
                Parent.PowerConsumption = 0;
                
                % Iterate through the children of this component.
                for Component = instance.Components
                    % Display the name of the child being iterated on, for
                    % debug purposes.
                    % disp("    Child:" + Component.Name); 
                    
                    % Get the stereotype property value of the child.
                    Child.Cost = Component.getValue("PhysicalProperties.Cost");
                    Child.Mass = Component.getValue("PhysicalProperties.Mass");
                    Child.PowerConsumption = Component.getValue("PhysicalProperties.PowerConsumption");
                    
                    % Add the stereotype property value of the child to the
                    % placeholder for the parent value.
                    Parent.Cost = Parent.Cost + Child.Cost;
                    Parent.Mass = Parent.Mass + Child.Mass;
                    Parent.PowerConsumption = Parent.PowerConsumption + Child.PowerConsumption;
                end
                
                % Set the value of the parent property based on the sum of
                % the child properties stored in the placeholder.
                setValue(instance, "PhysicalProperties.Cost", Parent.Cost);
                setValue(instance, "PhysicalProperties.Mass", Parent.Mass);
                setValue(instance, "PhysicalProperties.PowerConsumption", Parent.PowerConsumption);
                
            % The else condition can be used for debug to see if the
            % component was rejected as a parent.
            %else 
            %    disp("singular");
            end
        end
               
	end
end