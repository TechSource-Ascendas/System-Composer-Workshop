function [TargetPos] = GeneratePosition(inputs) %#ok<INUSD>

close all;
figure('Name','QuadcopterPath');
set(gca, 'XLim', [0 100], 'YLim', [0 100]);
hold on;

pos = randi(100, [1 2]);
TargetPos(1) = pos(1); % x
TargetPos(2)= pos(2); % y
TargetPos(3) = floor(rand*360); % orientation

plot(pos(1), pos(2), 'go', 'MarkerSize', 12);

end
