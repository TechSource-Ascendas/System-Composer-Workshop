function [Path,countIn] = PlanPathImpl(SelfPos, TargetPos)


% Turn in the X direction from current orientation
currOrient = SelfPos(3);
mov(1) = 1; % Turn counter-clockwise
turnAngle = 0;
if TargetPos(1) > SelfPos(1)
    turnAngle = 0;
    currOrient = 0;
elseif TargetPos(1) < SelfPos(1)
    turnAngle = 180;
    currOrient = 180;
end
mov(2) = turnAngle;
Path = mov;

if TargetPos(1) > SelfPos(1)
    mov(1) = 2; % Move forward
    mov(2) = TargetPos(1) - SelfPos(1);
    Path = [Path; mov];
elseif TargetPos(1) < SelfPos(1)
    mov(1) = 2; % Forward
    mov(2) = SelfPos(1) - TargetPos(1);
    Path = [Path; mov];
end

if TargetPos(2) > SelfPos(2)
    % Turn up
    mov(1) = 1; % Turn counter-clockwise
    mov(2) = 90;
    Path = [Path; mov];
    currOrient = 90;

    mov(1) = 2; % Move forward
    mov(2) = TargetPos(2) - SelfPos(2);
    Path = [Path; mov];


elseif TargetPos(2) < SelfPos(2)

    % Turn down
    mov(1) = 1; % Turn counter-clockwise
    mov(2) = 270;
    Path = [Path; mov];
    currOrient = 270;

    mov(1) = 2; % Forward
    mov(2) = SelfPos(2) - TargetPos(2);
    Path = [Path; mov];
    
end

% Final orientation
desiredOrient = TargetPos(3);
mov(1) = 1;
mov(2) = desiredOrient;
Path = [Path; mov];
% Initializing the Target reached flag

if SelfPos == TargetPos
    countIn = size(Path,1);
else
    countIn = 0;
end


end