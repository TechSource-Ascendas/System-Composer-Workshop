function [CountOut, NextCmd, PathOut] = IssueCommand(Path, countIn)

persistent orient
if isempty(orient)
    orient = [];
end

CountOut = countIn+1;
NextCmd = Path(CountOut, :);
PathOut = Path;

if NextCmd(1) == 1
    % Turn command
    orient = NextCmd(2);
else
    assert(NextCmd(1) == 2);
    dist = NextCmd(2);
    switch orient
        case {0, 360}
            [currX, currY] = getLastPosition(countIn);
            plotPath([currX, currY], [currX+dist, currY], CountOut);
        case 90
            [currX, currY] = getLastPosition(countIn);
            plotPath([currX, currY], [currX, currY+dist], CountOut);
        case 180
            [currX, currY] = getLastPosition(countIn);
            plotPath([currX currY], [currX-dist, currY], CountOut);
        case 270
            [currX, currY] = getLastPosition(countIn);
            plotPath([currX, currY], [currX, currY-dist], CountOut);
    end

end

end

function [currX, currY] = getLastPosition(CountIn)
if CountIn == 1
    quiv = findobj(gca, 'Tag', 'startpos');
else
    quiv = findobj(gca, 'Tag', ['pos' num2str(CountIn-1)]);
end
if isa(quiv, 'matlab.graphics.chart.primitive.Quiver')
    currX = quiv.XData(end) + quiv.UData(end);
    currY = quiv.YData(end) + quiv.VData(end);
else
    currX = quiv.XData(end);
    currY = quiv.YData(end);
end
end

function plotPath(p1,p2, count)

dp = p2-p1;
quiver(p1(1),p1(2),dp(1),dp(2),0, Tag=['pos', num2str(count)]);

end


% function [NextCmd, PathOut] = IssueCommand(Path)
%
% persistent orient CountOut
% if isempty(orient)
%     orient = [];
%     CountOut = 0;
% end
%
% CountOut = CountOut+1;
% NextCmd = Path(CountOut, :);
% PathOut = Path;
%
% if NextCmd(1) == 1
%     % Turn command
%     orient = NextCmd(2);
% else
%     assert(NextCmd(1) == 2);
%     dist = NextCmd(2);
%     switch orient
%         case {0, 360}
%             [currX, currY] = getLastPosition(CountOut-1);
%             plotPath([currX, currY], [currX+dist, currY], CountOut);
%         case 90
%             [currX, currY] = getLastPosition(CountOut-1);
%             plotPath([currX, currY], [currX, currY+dist], CountOut);
%         case 180
%             [currX, currY] = getLastPosition(CountOut-1);
%             plotPath([currX currY], [currX-dist, currY], CountOut);
%         case 270
%             [currX, currY] = getLastPosition(CountOut-1);
%             plotPath([currX, currY], [currX, currY-dist], CountOut);
%     end
%
% end
%
% end
%
% function [currX, currY] = getLastPosition(CountIn)
% if CountIn == 1
%     quiv = findobj(gca, 'Tag', 'startpos');
% else
%     quiv = findobj(gca, 'Tag', ['pos' num2str(CountIn-1)]);
% end
% if isa(quiv, 'matlab.graphics.chart.primitive.Quiver')
%     currX = quiv.XData(end) + quiv.UData(end);
%     currY = quiv.YData(end) + quiv.VData(end);
% else
%     currX = quiv.XData(end);
%     currY = quiv.YData(end);
% end
% end
%
% function plotPath(p1,p2, count)
%
% dp = p2-p1;
% quiver(p1(1),p1(2),dp(1),dp(2),0, Tag=['pos', num2str(count)]);
%
% end

% function [isFinished] = IssueCommand(Path)
% 
% orient = [];
% CountOut = 0;
% isFinished = false;
% 
% while ~isFinished
%     CountOut = CountOut + 1;
%     NextCmd = Path(CountOut, :);
% 
%     if NextCmd(1) == 1
%         % Turn command
%         orient = NextCmd(2);
%     else
%         assert(NextCmd(1) == 2);
%         dist = NextCmd(2);
%         switch orient
%             case {0, 360}
%                 [currX, currY] = getLastPosition(CountOut - 1);
%                 plotPath([currX, currY], [currX + dist, currY], CountOut);
%             case 90
%                 [currX, currY] = getLastPosition(CountOut - 1);
%                 plotPath([currX, currY], [currX, currY + dist], CountOut);
%             case 180
%                 [currX, currY] = getLastPosition(CountOut - 1);
%                 plotPath([currX, currY], [currX - dist, currY], CountOut);
%             case 270
%                 [currX, currY] = getLastPosition(CountOut - 1);
%                 plotPath([currX, currY], [currX, currY - dist], CountOut);
%         end
%     end
% 
%     % Check if the path is reached
%     if CountOut >= size(Path, 1)
%         isFinished = true;
%     end
% end
% end
% function [currX, currY] = getLastPosition(CountIn)
% if CountIn == 1
%     quiv = findobj(gca, 'Tag', 'startpos');
% else
%     quiv = findobj(gca, 'Tag', ['pos' num2str(CountIn - 1)]);
% end
% if isa(quiv, 'matlab.graphics.chart.primitive.Quiver')
%     currX = quiv.XData(end) + quiv.UData(end);
%     currY = quiv.YData(end) + quiv.VData(end);
% else
%     currX = quiv.XData(end);
%     currY = quiv.YData(end);
% end
% end
% 
% function plotPath(p1, p2, count)
% dp = p2 - p1;
% quiver(p1(1), p1(2), dp(1), dp(2), 0, 'Tag', ['pos', num2str(count)]);
% end


