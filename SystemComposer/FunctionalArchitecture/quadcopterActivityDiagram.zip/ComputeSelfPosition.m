function [selfPos] = ComputeSelfPosition(inputs)

pos = randi(100, [1 2]);
selfPos(1) = pos(1); % x
selfPos(2)= pos(2); % y
selfPos(3) = floor(rand*360); % orientation

plot(pos(1), pos(2), 'bx', 'MarkerSize', 12, 'Tag', 'startpos');

l = legend('Target Position', 'Self Position');
l.Location = 'northeastoutside';

end
