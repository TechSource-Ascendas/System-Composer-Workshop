function [OutputPin] = ApplyPathLimits(InputPin)
OutputPin = InputPin;
end
