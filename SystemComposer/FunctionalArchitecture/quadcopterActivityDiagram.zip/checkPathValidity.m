function isValid = checkPathValidity(path)
    % checkPathValidity checks the validity of a path matrix
    % path: a matrix where each row represents a command
    %       The first column is the command type (1 for turn, 2 for move)
    %       The second column is the value (angle for turn, distance for move)
    
    % Initialize the validity flag
    isValid = true;
    
    % Define valid ranges
    validCommandTypes = [1, 2]; % 1 for turn, 2 for move
    validAngleRange = [0, 360]; % Valid angles for turns
    validDistanceRange = [0, inf]; % Valid distances for moves (non-negative)
    
    % Iterate over each command in the path
    for i = 1:size(path, 1)
        commandType = path(i, 1);
        value = path(i, 2);
        
        % Check if command type is valid
        if ~ismember(commandType, validCommandTypes)
            isValid = false;
            fprintf('Invalid command type at row %d: %d\n', i, commandType);
            break;
        end
        
        % Check if value is valid based on command type
        if commandType == 1 % Turn command
            if value < validAngleRange(1) || value > validAngleRange(2)
                isValid = false;
                fprintf('Invalid turn angle at row %d: %d\n', i, value);
                break;
            end
        elseif commandType == 2 % Move command
            if value < validDistanceRange(1) || value > validDistanceRange(2)
                isValid = false;
                fprintf('Invalid move distance at row %d: %d\n', i, value);
                break;
            end
        end
    end
end