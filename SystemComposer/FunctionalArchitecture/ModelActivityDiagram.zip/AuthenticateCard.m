function authenticate = AuthenticateCard(cardStatus)
    if cardStatus > 1
        authenticate = 0;
        disp("Authenticating failed - " + authenticate);
        return;
    end
    
    authenticate = 1;
    disp("Authenticating passed - " + authenticate);
end