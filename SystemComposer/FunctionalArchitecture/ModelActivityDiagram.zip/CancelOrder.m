function [outputArg1,outputArg2] = CancelOrder(inputArg1,inputArg2)
%CANCELORDER undefined
%   undefined
arguments (Input)
    inputArg1
    inputArg2
end

arguments (Output)
    outputArg1
    outputArg2
end

outputArg1 = inputArg1;
outputArg2 = inputArg2;
end