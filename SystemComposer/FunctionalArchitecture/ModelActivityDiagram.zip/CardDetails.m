function output = CardDetails(item,status)
    disp("Item selected: " + item);
    disp("Card Status Code: " + status);
    output = status;
end