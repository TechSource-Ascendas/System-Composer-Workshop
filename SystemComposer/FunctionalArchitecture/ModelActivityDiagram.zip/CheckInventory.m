function inventory = CheckInventory(token)
    disp("Check inventory: " + token);
    item_inventory = [1, 0, 4, 5];
    if item_inventory(token) >= 1
        inventory = 1 ; % yes
    else 
        inventory = 0; %no
    end