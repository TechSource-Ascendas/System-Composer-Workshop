function [item,status] = PlaceOrder()
items = {'Apple', 'Banana', 'Cherry', 'Date'};
cardStatus = {'Good','Bad'};
item = randi(4,1);
status = randi(2,1);
ordered_item = items{item};

disp("You selected: " + ordered_item);
disp("Card status: " + cardStatus{status});
end